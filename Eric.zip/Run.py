# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 2.7.17 (default, Sep 30 2020, 13:38:04) 
# [GCC 7.5.0]
# Warning: this version of Python has problems handling the Python 3 "byte" type in constants properly.

# Embedded file name: chatServer.py
# Compiled at: 2021-07-25 04:42:59
# Size of source mod 2**32: 18410 bytes
import sys, socket, select, signal, json, ast, threading, time, os, random, concurrent.futures, asyncio
from requests import get
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser

def randomCT():
    num = '1234567890'
    ct = ''
    for c in range(10):
        d = random.choice(num)
        ct += '{}'.format(d)

    return ct


class Server:

    class War:

        def __init__(self):
            self.cache = []
            self.korban = {}
            self.pala = None

        def __call__(self, createdTime, bot, korban):
            key = createdTime
            if key in self.cache:
                if bot == self.pala:
                    return True
                else:
                    return False
            self.cache.append(key)
            if len(self.cache) == 20:
                self.cache = []
            if korban != None:
                self.korban[korban] = True
            if self.pala == None:
                self.pala = bot
                self.korban[bot] = True
                return True
            if korban == self.pala:
                self.pala = bot
                self.korban[bot] = True
                return True
            else:
                if bot in self.korban:
                    self.pala = bot
                    return True
                return False

    class Messenger:

        def __init__(self):
            self.cache = []

        def __call__(self, createdTime):
            key = createdTime
            if key in self.cache:
                return False
            else:
                self.cache.append(key)
                if len(self.cache) == 20:
                    self.cache = []
                return True

    def __init__(self, sockaddr):
        self.connsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.connsock.bind(sockaddr)
        self.connsock.listen(1)
        self.upgrade = None
        self.blacklist = {}
        self.cacheTime = {}
        self.cache = []
        self.multy = {}
        self.alltoken = []
        self.terkick = {}
        self.sendPlay = {}
        self.count = {}
        self.reqStat = {}
        self.pala = ''
        self.war = False
        self.messenger = Server.Messenger()
        self.Wars = Server.War()
        self.power_queue = asyncio.get_event_loop()
        self.ajs = []
        self.startWar = False
        self.timeWar = 0
        self.lockSquad = False
        print('正在接收的IP {}...'.format(self.connsock.getsockname()))
        self.users = {}
        self.datas = {'pro':{},  'whiteList':{},  'blackList':{}}
        self.botStatus = {}

    def autoRestart(self, c):
        time.sleep(c)
        if self.users == {}:
            python = sys.executable
            (os.execl)(python, python, *sys.argv)

    def __broadcast__(self, datasock, payload):
        for s in self.users.values():
            if s is not datasock:
                s.sendall(payload)

    def __broadcastQr__(self, datasock, payload):
        for s in self.sendPlay.values():
            if s is not datasock:
                s.sendall(payload)
                time.sleep(0.001)

    def __disconnected__(self, datasock):
        for key in self.users:
            if key in datasock.recv(2048).decode():
                del self.users[key]
                print('users [{}] > Logout'.format(key))

    async def __queue__(self, datasock):
        reciv = datasock.recv(9000).decode('utf-8')
        try:
            payload = ast.literal_eval(reciv)
        except:
            return
        else:
            func = payload['func']
            data = payload
            if func != 'queue':
                if func == 'update':
                    bots = []
                    for b in self.users:
                        bots.append(b)

                    gc = data['group']
                    usbot = data['userBots']
                    squad = {'squad':bots,  'group':gc}
                    num = ''
                    for c in data['file']:
                        if c in '1234567890':
                            num += c

                    self.count[num] = usbot
                    self.users[usbot].sendall(str({'bots':squad,  'func':'update'}).encode('utf-8'))
                    self.lockSquad = True
                    return
                else:
                    if func == 'bqr':
                        to = data['bot']
                        self.users[to].sendall(str(payload).encode('utf-8'))
                        return
                    else:
                        if func == 'bqrall':
                            for b in self.sendPlay:
                                if b not in self.ajs:
                                    self.users[b].sendall(str(payload).encode('utf-8'))

                            return
                        else:
                            if func == 'upgrade':
                                if data['userBots'] != self.upgrade:
                                    return
                                filename = data['filename']
                                local = data['local']
                                for s in self.users.values():
                                    s.sendall(str({'func':'upgrade',  'local':local}).encode('utf-8'))

                                time.sleep(5)
                                f = open(filename, 'rb')
                                while 1:
                                    l = f.read(1024)
                                    while l:
                                        for s in self.users.values():
                                            s.sendall(l)

                                        l = f.read(1024)

                                    if not l:
                                        f.close()
                                        time.sleep(1)
                                        python = sys.executable
                                        (os.execl)(python, python, *sys.argv)

                            else:
                                if func == 'putbtamp':
                                    for s in self.users.values():
                                        s.sendall(str(payload).encode('utf-8'))

                                else:
                                    if func == 'cbtampall':
                                        for s in self.users.values():
                                            s.sendall(str(payload).encode('utf-8'))

                                    else:
                                        if func == 'cbtamps':
                                            for s in self.users.values():
                                                s.sendall(str(payload).encode('utf-8'))

                                        else:
                                            if func == 'clearban':
                                                for s in self.users.values():
                                                    s.sendall(str(payload).encode('utf-8'))

                                                self.blacklist = {}
                                                self.cache = []
                                                self.multy = {}
                                                self.terkick = {}
                                                self.sendPlay = {}
                                                self.Wars.korban = {}
                                                self.Wars.pala = None
                                                self.pala = ''
                                                self.war = False
                                                self.Restart()
                                            else:
                                                if func == 'restarting':
                                                    for s in self.users.values():
                                                        s.sendall(str(payload).encode('utf-8'))

                                                    self.Restart()
                                                else:
                                                    if func == 'mode':
                                                        for s in self.users.values():
                                                            s.sendall(str(payload).encode('utf-8'))

                                                        self.Restart()
                                                    else:
                                                        if func == 'scert':
                                                            for s in self.users.values():
                                                                if s is not datasock:
                                                                    s.sendall(str(payload).encode('utf-8'))

                                                            self.Restart()
                                                        if func == 'crun':
                                                            for s in self.users.values():
                                                                s.sendall(str(payload).encode('utf-8'))

                                                            self.Restart()
                                                        if func == 'ticket' or func == 'protect' or func == 'resetdata' or func == 'expel' or func == 'addowner' or func == 'addstaff' or func == 'btamps':
                                                            for s in self.users.values():
                                                                s.sendall(str(payload).encode('utf-8'))

                                                            return
                                                    if func == 'starting':
                                                        usbot = data['userBots']
                                                        status = data['status']
                                                        self.botStatus[usbot] = status
                                                if func == 'gaskeun':
                                                    for s in self.users.values():
                                                        s.sendall(str(payload).encode('utf-8'))

                                                    return
                                            if func == 'resp':
                                                group = data['group']
                                                for r in range(50):
                                                    if r != 0:
                                                        c = '{}'.format(r)
                                                        if c in self.count:
                                                            self.users[self.count[c]].sendall(str({'func':'resp',  'group':group,  'txt':r}).encode('utf-8'))
                                                        time.sleep(0.01)

                                                return
                                        if func == 'reqstat':
                                            self.reqStat = {'bot':data['bot'], 
                                             'group':data['group'],  'statAll':{}}
                                            for s in self.users.values():
                                                s.sendall(str({'func': 'reqstat'}).encode('utf-8'))
                                                time.sleep(0.01)

                                            return
                                    if func == 'getstat':
                                        bot = data['bot']
                                        duedate = data['duedate']
                                        self.reqStat['statAll'][bot] = duedate
                                        if len(self.reqStat['statAll']) == len(self.count):
                                            self.users[self.reqStat['bot']].sendall(str({'func':'getstat',  'data':self.reqStat['statAll'],  'group':self.reqStat['group']}).encode('utf-8'))
                                            self.reqStat = {}
                                        return
                                if func == 'uptok':
                                    squad = self.alltoken + data['squad']
                                    self.alltoken = squad
                                    self.ajs = data['ajs']
                                    return
                            if func == 'addtoken':
                                new = data['new']
                                bot = data['bot']
                                kembar = []
                                for ex in new:
                                    if ex in self.alltoken:
                                        new.remove(ex)
                                        kembar.append(ex)

                                group = data['group']
                                if len(new) >= len(self.users):
                                    for s in self.users.values():
                                        token = random.choice(new)
                                        new.remove(token)
                                        s.sendall(str({'func':'addtoken',  'token':token,  'bot':bot,  'group':group}).encode('utf-8'))
                                        print(token)

                                else:
                                    self.users[bot].sendall(str({'func':'addtokenFailed',  'group':group,  'kembar':kembar}).encode('utf-8'))
                                return
                        if func == 'antioff':
                            bot = data['bot']
                            group = data['group']
                            self.ajs = []
                            for s in self.users.values():
                                s.sendall(str({'func':'antioff',  'group':group,  'bot':bot}).encode('utf-8'))

                            return
                    if func == 'antistay':
                        bot = data['bot']
                        count = data['count']
                        group = data['group']
                        stop = 0
                        ajs = []
                        for b in self.botStatus:
                            if not self.botStatus[b]:
                                if b != bot:
                                    if stop != count:
                                        stop += 1
                                        ajs.append(b)
                                    else:
                                        break

                        self.ajs = ajs
                        for s in self.users.values():
                            s.sendall(str({'func':'antistay',  'group':group,  'ajs':ajs,  'bot':bot}).encode('utf-8'))

                        return
                if func == 'forceJoin':
                    usbot = data['userBots']
                    count = data['count']
                    group = data['group']
                    ticket = data['ticket']
                    ready = []
                    num = 0
                    limit = []
                    for b in self.botStatus:
                        if b not in self.ajs:
                            if self.botStatus[b] == False:
                                if num != count:
                                    ready.append(b)
                                    num += 1
                            else:
                                limit.append(b)

                    if limit == []:
                        for r in self.users:
                            if r not in data['stay']:
                                self.users[r].sendall(str({'func':'staySquad',  'bots':ready,  'limit':[],  'group':group,  'ticket':ticket}).encode('utf-8'))
                            else:
                                self.users[r].sendall(str({'func':'stayBots',  'capten':usbot,  'bots':ready,  'limit':[],  'group':group}).encode('utf-8'))

                    else:
                        for r in self.users:
                            if r not in data['stay']:
                                self.users[r].sendall(str({'func':'staySquad',  'bots':ready,  'limit':limit,  'group':group,  'ticket':ticket}).encode('utf-8'))
                            else:
                                self.users[r].sendall(str({'func':'stayBots',  'capten':usbot,  'bots':ready,  'limit':limit,  'group':group}).encode('utf-8'))

                else:
                    self.__broadcast__(datasock, str(payload).encode('utf-8'))
            else:
                try:
                    queue = data['To']
                    status = data['status']
                    self.botStatus[queue] = status
                    black = data['blacklist']
                    terkick = data['terkick']
                    Bl = self.listBL()
                    if black != []:
                        for b in black:
                            self.blacklist[b] = True

                    createdTime = data['op']['createdTime']
                    if createdTime in self.cacheTime[queue]:
                        if self.cacheTime[queue][createdTime]:
                            self.users[queue].sendall(str({'hasil':True,  'Time':createdTime,  'func':'queue',  'blacklist':[],  'pala':self.pala}).encode('utf-8'))
                        else:
                            self.users[queue].sendall(str({'hasil':False,  'Time':createdTime,  'func':'queue',  'blacklist':[],  'pala':self.pala}).encode('utf-8'))
                            self.multy[queue] += 1
                        if self.multy[queue] == 5:
                            self.cacheTime[queue] = {}
                            self.multy[queue] = 0
                    else:
                        hasil = self.messenger(createdTime)
                        if hasil:
                            self.sendPlay[queue] = self.users[queue]
                            self.pala = queue
                        if terkick != None:
                            self.sendPlay[terkick] = self.users[terkick]
                        self.users[queue].sendall(str({'hasil':hasil,  'Time':createdTime,  'func':'queue',  'blacklist':Bl,  'pala':self.pala}).encode('utf-8'))
                        self.cacheTime[queue] = {createdTime: hasil}
                        self.multy[queue] = 0
                        return
                except:
                    pass

    def timeLeftWar(self, times, crtm):
        time.sleep(times)
        self.timeWar -= times
        if self.timeWar == 0:
            for b in self.sendPlay:
                self.users[b].sendall(str({'func':'stabilizer',  'bot':self.pala,  'crtm':crtm}).encode('utf-8'))
                self.startWar = False
                self.cache = []
                self.multy = {}
                self.terkick = {}
                self.sendPlay = {}
                self.Wars.korban = {}
                self.Wars.cache = []
                self.Wars.pala = None
                self.pala = ''
                self.war = False

            return
        else:
            return self.timeLeftWar(self.timeWar, crtm)

    def __forward__(self, datasock):
        payload = datasock.recv(2048)
        if payload:
            dst = json.loads(payload.decode('utf-8'))['To']
            if dst == 'all':
                self.__broadcast__(datasock, payload)
            else:
                self.users[dst].sendall(payload)

    def listBL(self):
        bl = [mid for mid in self.blacklist]
        return bl

    def autorestart(self):
        for s in self.users.values():
            try:
                s.sendall(str({'func': 'restart'}).encode('utf-8'))
            except:
                pass

        time.sleep(1)
        print('SYSTEM RESTART')
        python = sys.executable
        (os.execl)(python, python, *sys.argv)

    def Restart(self):
        time.sleep(1)
        python = sys.executable
        (os.execl)(python, python, *sys.argv)

    def __serve__(self, ready):
        for s in ready:
            if s is self.connsock:
                datasock, peername = self.connsock.accept()
                data = datasock.recv(2048).decode()
                username = ''
                a = ast.literal_eval(data)
                if type(a) is not dict:
                    pass
                else:
                    for m in a:
                        username = m
                        if not self.lockSquad and username not in self.users:
                            num = ''
                            for c in a[m]:
                                for i in c:
                                    if i in '1234567890':
                                        num += i

                            self.count[num] = username
                            self.users[username] = datasock
                            self.cacheTime[username] = {}
                            self.multy[username] = 0
                            self.botStatus[username] = False
                            if self.upgrade == None:
                                self.upgrade = username
                            print('Bots: {}\nConnected from IP: {}'.format(username, peername))
                        else:
                            if username in self.users:
                                self.users[username] = datasock

            else:
                self.power_queue.run_until_complete(self.__queue__(s))

    def run(self):
        print('主機上線完畢..\n')
        while True:
            try:
                signal.signal(signal.SIGINT, signal.default_int_handler)
                ready, _, _ = select.select([self.connsock] + list(self.users.values()), [], [])
                self.__serve__(ready)
            except:
                pass


now = time.time()
startTime = '2022-8-13 06:22:00'
duedate = parser.parse(startTime) + relativedelta()
timeleft = duedate - datetime.now()
days, seconds = timeleft.days, timeleft.seconds
hours = seconds / 3600
minutes = seconds / 60 % 60
hari = hours % seconds * minutes * days
exp = days
if 0 == exp:
    exp = int(hours)
    if 0 == exp:
        exp = int(minutes)
        if 0 == exp:
            exp = int(seconds)
print('\x1b[3;31;47m' + '您剩於： {} 天 {} 小時, {} 分鐘的使用時間 \x1b[0m'.format(days, int(hours), int(minutes)) + '\x1b[0m')
if exp >= 1:
    ip = sys.argv[1]
    if 20 >= len(ip):
        if __name__ == '__main__':
            sockaddr = (
             ip, 9666)
            app = Server(sockaddr)
            app.run()
    else:
        python = sys.executable
        (os.execl)(python, python, *sys.argv)